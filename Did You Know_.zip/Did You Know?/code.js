onEvent("StartButton", "click", function( ) {
  setScreen("CategoryScreen");
});
onEvent("StrangeLawsButton", "click", function( ) {
  setScreen("StrangeLaws1");
});
onEvent("NBL1", "click", function( ) {
  setScreen("Strangelaws2");
});
onEvent("BBL2", "click", function( ) {
  setScreen("StrangeLaws1");
});
onEvent("NBL2", "click", function( ) {
  setScreen("StrangeLaws3");
});
onEvent("BBL3", "click", function( ) {
  setScreen("Strangelaws2");
});
onEvent("NBL3", "click", function( ) {
  setScreen("Strangelaws4");
});
onEvent("BBL4", "click", function( ) {
  setScreen("StrangeLaws3");
});
onEvent("NBL4", "click", function( ) {
  setScreen("StrangeLaws5");
});
onEvent("BBL5", "click", function( ) {
  setScreen("Strangelaws4");
});
onEvent("NBL5", "click", function( ) {
  setScreen("StrangeLaws7");
});
onEvent("NBL6", "click", function( ) {
  setScreen("StrangeLaws7");
});
onEvent("BBL6", "click", function( ) {
  setScreen("StrangeLaws5");
});
onEvent("NBL7", "click", function( ) {
  setScreen("StrangeLaws8");
});
onEvent("NBL8", "click", function( ) {
  setScreen("StrangeLaws9");
});
onEvent("BBL8", "click", function( ) {
  setScreen("StrangeLaws7");
});
onEvent("BBL9", "click", function( ) {
  setScreen("StrangeLaws8");
});
onEvent("NBL9", "click", function( ) {
  setScreen("StrangeLaws10");
});
onEvent("NBL10", "click", function( ) {
  setScreen("StrangeLawsEnd");
});
onEvent("BBL10", "click", function( ) {
  setScreen("StrangeLaws9");
});
onEvent("SLHome", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("BBL11", "click", function( ) {
  setScreen("StrangeLaws10");
});
onEvent("AnimalButton", "click", function( ) {
  setScreen("Animals1");
});
onEvent("NBA1", "click", function( ) {
  setScreen("Animals2");
});
onEvent("BBA2", "click", function( ) {
  setScreen("Animals1");
});
onEvent("NBA2", "click", function( ) {
  setScreen("Animals3");
});
onEvent("BBA3", "click", function( ) {
  setScreen("Animals2");
});
onEvent("NBA3", "click", function( ) {
  setScreen("Animals4");
});
onEvent("BBA4", "click", function( ) {
  setScreen("Animals3");
});
onEvent("NBA4", "click", function( ) {
  setScreen("Animals5");
});
onEvent("BBA5", "click", function( ) {
  setScreen("Animals4");
});
onEvent("NBA5", "click", function( ) {
  setScreen("Animals6");
});
onEvent("BBA6", "click", function( ) {
  setScreen("Animals5");
});
onEvent("NBA6", "click", function( ) {
  setScreen("Animals7");
});
onEvent("BBA7", "click", function( ) {
  setScreen("Animals6");
});
onEvent("NBA7", "click", function( ) {
  setScreen("Animals8");
});
onEvent("BBA8", "click", function( ) {
  setScreen("Animals7");
});
onEvent("NBA8", "click", function( ) {
  setScreen("Animals9");
});
onEvent("BBA9", "click", function( ) {
  setScreen("Animals8");
});
onEvent("NBA9", "click", function( ) {
  setScreen("Animals10");
});
onEvent("BBA10", "click", function( ) {
  setScreen("Animals9");
});
onEvent("NBA10", "click", function( ) {
  setScreen("AnimalsEnd");
});
onEvent("BBA11", "click", function( ) {
  setScreen("Animals10");
});
onEvent("EBA", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("PresidentButton", "click", function( ) {
  setScreen("Presidents1");
});
onEvent("NBP1", "click", function( ) {
  setScreen("Presidents2");
});
onEvent("BBP2", "click", function( ) {
  setScreen("Presidents1");
});
onEvent("NBP2", "click", function( ) {
  setScreen("Presidents3");
});
onEvent("BBP3", "click", function( ) {
  setScreen("Presidents2");
});
onEvent("NBP3", "click", function( ) {
  setScreen("Presidents4");
});
onEvent("BBP4", "click", function( ) {
  setScreen("Presidents3");
});
onEvent("NBP4", "click", function( ) {
  setScreen("Presidents5");
});
onEvent("BBP5", "click", function( ) {
  setScreen("Presidents4");
});
onEvent("NBP5", "click", function( ) {
  setScreen("Presidents6");
});
onEvent("BBP6", "click", function( ) {
  setScreen("Presidents5");
});
onEvent("NBP6", "click", function( ) {
  setScreen("Presidents7");
});
onEvent("BBP7", "click", function( ) {
  setScreen("Presidents6");
});
onEvent("NBP7", "click", function( ) {
  setScreen("Presidents8");
});
onEvent("BBP8", "click", function( ) {
  setScreen("Presidents7");
});
onEvent("NBP8", "click", function( ) {
  setScreen("Presidents9");
});
onEvent("BBP9", "click", function( ) {
  setScreen("Presidents8");
});
onEvent("NBP9", "click", function( ) {
  setScreen("Presidents10");
});
onEvent("BBP10", "click", function( ) {
  setScreen("Presidents9");
});
onEvent("NBP10", "click", function( ) {
  setScreen("PresidentsEnd");
});
onEvent("BBP11", "click", function( ) {
  setScreen("Presidents10");
});
onEvent("EBP", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("RandomButton", "click", function( ) {
  setScreen("Random1");
});
onEvent("NBR1", "click", function( ) {
  setScreen("Random2");
});
onEvent("BBR2", "click", function( ) {
  setScreen("Random1");
});
onEvent("NBR2", "click", function( ) {
  setScreen("Random3");
});
onEvent("BBR3", "click", function( ) {
  setScreen("Random2");
});
onEvent("NBR3", "click", function( ) {
  setScreen("Random4");
});
onEvent("BBR4", "click", function( ) {
  setScreen("Random3");
});
onEvent("NBR4", "click", function( ) {
  setScreen("Random5");
});
onEvent("BBR5", "click", function( ) {
  setScreen("Random4");
});
onEvent("NBR5", "click", function( ) {
  setScreen("Random6");
});
onEvent("BBR6", "click", function( ) {
  setScreen("Random5");
});
onEvent("NBR6", "click", function( ) {
  setScreen("Random7");
});
onEvent("BBR7", "click", function( ) {
  setScreen("Random6");
});
onEvent("NBR7", "click", function( ) {
  setScreen("Random8");
});
onEvent("BBR8", "click", function( ) {
  setScreen("Random7");
});
onEvent("NBR8", "click", function( ) {
  setScreen("Random9");
});
onEvent("BBR9", "click", function( ) {
  setScreen("Random8");
});
onEvent("NBR9", "click", function( ) {
  setScreen("Random10");
});
onEvent("BBR10", "click", function( ) {
  setScreen("Random9");
});
onEvent("NBR10", "click", function( ) {
  setScreen("RandomEnd");
});
onEvent("EBR", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("BBR11", "click", function( ) {
  setScreen("Random10");
});
onEvent("BBL7", "click", function( ) {
  setScreen("StrangeLaws6");
});
onEvent("HomeButtonAnimals", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("HomeBUTTONPRESIDENTS", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("HomebuttonRandom", "click", function( ) {
  setScreen("StartScreeen");
});
onEvent("HomeButtonLaws", "click", function( ) {
  setScreen("StartScreeen");
});
